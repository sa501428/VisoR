/** Automatically generated file. DO NOT MODIFY */
package com.visor.visionhacker;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}